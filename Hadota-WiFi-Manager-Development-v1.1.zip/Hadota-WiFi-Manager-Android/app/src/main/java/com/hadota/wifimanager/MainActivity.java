package com.hadota.wifimanager;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URI;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(11,16,23));
        getWindow().setNavigationBarColor(Color.rgb(11,16,23));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(11,16,23));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface public void testRouter() {
            executor.execute(() -> {
                HttpURLConnection connection = null;
                boolean ok = false;
                String message;
                long started = System.currentTimeMillis();
                try {
                    URL url = new URL("http://192.168.1.1/");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(5000);
                    connection.setReadTimeout(5000);
                    connection.setInstanceFollowRedirects(false);
                    connection.setRequestProperty("User-Agent", "HadotaWiFiManager/1.1");
                    int code = connection.getResponseCode();
                    long elapsed = System.currentTimeMillis() - started;
                    String server = connection.getHeaderField("Server");
                    String location = connection.getHeaderField("Location");
                    ok = code >= 200 && code < 500;
                    StringBuilder details = new StringBuilder();
                    details.append("استجابة الراوتر: HTTP ").append(code)
                           .append("\nزمن الاستجابة: ").append(elapsed).append(" ms");
                    if (server != null && !server.isEmpty()) details.append("\nالخادم: ").append(server);
                    if (location != null && !location.isEmpty()) details.append("\nإعادة توجيه إلى: ").append(location);
                    details.append("\n\nهذا اختبار وصول وقراءة معلومات عامة فقط؛ لم تتم محاولة تسجيل الدخول أو تغيير إعدادات الراوتر.");
                    message = details.toString();
                } catch (Exception e) {
                    message = "تعذر الوصول إلى 192.168.1.1. تأكد من اتصال الهاتف بشبكة الكافيه، ثم تحقق من عنوان البوابة في إعدادات Wi‑Fi.";
                } finally {
                    if (connection != null) connection.disconnect();
                }
                final boolean result = ok;
                final String text = message;
                runOnUiThread(() -> {
                    if (web != null) web.evaluateJavascript("routerResult(" + result + "," + org.json.JSONObject.quote(text) + ")", null);
                });
            });
        }
    }

    @Override protected void onDestroy() {
        if (web != null) { web.removeJavascriptInterface("AndroidBridge"); web.destroy(); web = null; }
        executor.shutdownNow();
        super.onDestroy();
    }
}
