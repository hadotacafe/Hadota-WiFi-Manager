package com.hadota.wifimanager;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URI;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(11,16,23));
        getWindow().setNavigationBarColor(Color.rgb(11,16,23));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(11,16,23));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface public void testRouter() {
            executor.execute(() -> {
                HttpURLConnection connection = null;
                boolean ok = false;
                String message;
                long started = System.currentTimeMillis();
                try {
                    URL url = new URL("http://192.168.1.1/");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(5000);
                    connection.setReadTimeout(5000);
                    connection.setInstanceFollowRedirects(false);
                    connection.setRequestProperty("User-Agent", "HadotaWiFiManager/1.1");
                    int code = connection.getResponseCode();
                    long elapsed = System.currentTimeMillis() - started;
                    String server = connection.getHeaderField("Server");
                    String location = connection.getHeaderField("Location");
                    ok = code >= 200 && code < 500;
                    StringBuilder details = new StringBuilder();
                    details.append("استجابة الراوتر: HTTP ").append(code)
                           .append("\nزمن الاستجابة: ").append(elapsed).append(" ms");
                    if (server != null && !server.isEmpty()) details.append("\nالخادم: ").append(server);
                    if (location != null && !location.isEmpty()) details.append("\nإعادة توجيه إلى: ").append(location);
                    details.append("\n\nهذا اختبار وصول وقراءة معلومات عامة فقط؛ لم تتم محاولة تسجيل الدخول أو تغيير إعدادات الراوتر.");
                    message = details.toString();
                } catch (Exception e) {
                    message = "تعذر الوصول إلى 192.168.1.1. تأكد من اتصال الهاتف بشبكة الكافيه، ثم تحقق من عنوان البوابة في إعدادات Wi‑Fi.";
                } finally {
                    if (connection != null) connection.disconnect();
                }
                final boolean result = ok;
                final String text = message;
                runOnUiThread(() -> {
                    if (web != null) web.evaluateJavascript("routerResult(" + result + "," + org.json.JSONObject.quote(text) + ")", null);
                });
            });
        }

        @JavascriptInterface public void inspectRouterLogin() {
            executor.execute(() -> {
                HttpURLConnection connection = null;
                String message;
                try {
                    URL url = new URL("http://192.168.1.1/");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(7000);
                    connection.setReadTimeout(7000);
                    connection.setInstanceFollowRedirects(true);
                    connection.setRequestProperty("User-Agent", "HadotaWiFiManager/1.2");
                    int code = connection.getResponseCode();
                    String finalUrl = connection.getURL().toString();
                    InputStream stream = code >= 400 ? connection.getErrorStream() : connection.getInputStream();
                    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                    if (stream != null) {
                        byte[] chunk = new byte[4096]; int count; int total = 0;
                        while ((count = stream.read(chunk)) > 0 && total < 180000) {
                            int take = Math.min(count, 180000 - total); buffer.write(chunk, 0, take); total += take;
                        }
                        stream.close();
                    }
                    String html = buffer.toString("UTF-8");
                    Matcher titleMatch = Pattern.compile("(?is)<title[^>]*>(.*?)</title>").matcher(html);
                    String title = titleMatch.find() ? titleMatch.group(1).replaceAll("<[^>]+>", " ").trim() : "غير ظاهر";
                    Matcher formMatch = Pattern.compile("(?is)<form\\b([^>]*)>").matcher(html);
                    String form = formMatch.find() ? "نموذج HTML موجود" : "لم يظهر نموذج HTML مباشر (قد تكون الصفحة مبنية بجافاسكريبت)";
                    Matcher inputMatch = Pattern.compile("(?is)<input\\b([^>]*)>").matcher(html);
                    StringBuilder fields = new StringBuilder(); int fieldCount = 0;
                    while (inputMatch.find() && fieldCount < 18) {
                        String attrs = inputMatch.group(1);
                        Matcher nameMatch = Pattern.compile("(?is)\\bname\\s*=\\s*['\"]([^'\"]+)['\"]").matcher(attrs);
                        Matcher typeMatch = Pattern.compile("(?is)\\btype\\s*=\\s*['\"]([^'\"]+)['\"]").matcher(attrs);
                        if (nameMatch.find()) { if (fieldCount > 0) fields.append(", "); fields.append(nameMatch.group(1)); if (typeMatch.find()) fields.append(" [").append(typeMatch.group(1)).append("]"); fieldCount++; }
                    }
                    Matcher scriptMatch = Pattern.compile("(?is)<script\\b([^>]*)>").matcher(html);
                    StringBuilder scripts = new StringBuilder(); int scriptCount = 0;
                    while (scriptMatch.find() && scriptCount < 10) {
                        Matcher srcMatch = Pattern.compile("(?is)\\bsrc\\s*=\\s*['\"]([^'\"]+)['\"]").matcher(scriptMatch.group(1));
                        if (srcMatch.find()) { if (scriptCount > 0) scripts.append(", "); scripts.append(srcMatch.group(1)); scriptCount++; }
                    }
                    message = "فحص قراءة فقط — HTTP " + code + "\nالعنوان النهائي: " + finalUrl + "\nعنوان الصفحة: " + title + "\n" + form + "\nحقول الصفحة: " + (fields.length() == 0 ? "لا توجد حقول ظاهرة" : fields) + "\nملفات JavaScript: " + (scripts.length() == 0 ? "لا توجد ملفات مرتبطة ظاهرة" : scripts) + "\nحجم HTML المقروء: " + html.length() + " حرفًا\n\nلم يتم تسجيل الدخول أو إرسال بيانات أو تغيير أي إعداد.";
                } catch (Exception e) {
                    message = "تعذر فحص صفحة الراوتر: " + e.getMessage();
                } finally {
                    if (connection != null) connection.disconnect();
                }
                final String result = message;
                runOnUiThread(() -> { if (web != null) web.evaluateJavascript("routerInspectResult(" + org.json.JSONObject.quote(result) + ")", null); });
            });
        }
    }

    @Override protected void onDestroy() {
        if (web != null) { web.removeJavascriptInterface("AndroidBridge"); web.destroy(); web = null; }
        executor.shutdownNow();
        super.onDestroy();
    }
}
