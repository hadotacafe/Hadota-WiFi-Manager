# Hadota WiFi Manager — Development v1.3

## Updates
- Detects the current Wi-Fi default gateway from Android DHCP information.
- Uses the detected gateway for connectivity checks and read-only login-page inspection.
- Displays the detected gateway in the app.
- Adds ACCESS_WIFI_STATE permission and increments Android version to 1.3 (versionCode 4).

## Important limitations
This build does not authenticate to the router, enumerate connected clients, or apply QoS/speed limits. The ZTE H188A firmware interface and authenticated session/API behavior must be validated before implementing those operations. No router settings are changed by this build.

## Build
Open this project in Android Studio or run `gradle assembleDebug` with Android SDK and Gradle installed.
