# Hadota WiFi Manager — Development v1.4

## Updates
- Keeps automatic detection of the Android Wi-Fi default gateway.
- Keeps connectivity and login-page inspection in read-only mode.
- Adds read-only inspection of same-router JavaScript files referenced by the login page.
- Lists candidate local paths that may relate to DHCP, connected devices, WLAN, LAN, login, tokens, or status.
- Skips script URLs hosted on other domains.
- Android versionCode 5, versionName 1.4.

## Important limitations
This build does not authenticate to the router, enumerate connected clients, or apply QoS/speed limits. The discovered paths are candidates only, not confirmed APIs. The ZTE H188A firmware's login challenge, session handling, and device-list endpoints still need to be verified before implementing authentication or control. No router settings are changed by this build.

## Build
Open this project in Android Studio or run `gradle assembleDebug` with Android SDK and Gradle installed.
