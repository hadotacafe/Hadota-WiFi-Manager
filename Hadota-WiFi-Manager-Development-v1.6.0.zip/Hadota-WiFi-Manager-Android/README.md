# Hadota WiFi Manager — Development v1.4.1

## Updates
- Keeps automatic detection of the Android Wi-Fi default gateway.
- Keeps connectivity and login-page inspection in read-only mode.
- Adds read-only inspection of same-router JavaScript files referenced by the login page.
- Lists candidate local paths that may relate to DHCP, connected devices, WLAN, LAN, login, tokens, or status.
- Skips script URLs hosted on other domains.
- Android versionCode 6, versionName 1.4.1.

## Important limitations
This build does not authenticate to the router, enumerate connected clients, or apply QoS/speed limits. The discovered paths are candidates only, not confirmed APIs. The ZTE H188A firmware's login challenge, session handling, and device-list endpoints still need to be verified before implementing authentication or control. No router settings are changed by this build.

## Build
Open this project in Android Studio or run `gradle assembleDebug` with Android SDK and Gradle installed.

## v1.4.1 hotfix
- Fixes the JavaScript bridge placement so the read-only script analysis method is exposed by AndroidBridge.
\n\n## v1.6.0\n- Adds an embedded router WebView panel. Log in manually to the local ZTE router, navigate to WLAN Client Status and LAN Client Status, then use the in-page Hadota import button to extract the currently visible client list into local inventory.\n- The router login is entered only in the router page; the app does not collect or transmit credentials.\n- QoS changes are not implemented in this build.\n