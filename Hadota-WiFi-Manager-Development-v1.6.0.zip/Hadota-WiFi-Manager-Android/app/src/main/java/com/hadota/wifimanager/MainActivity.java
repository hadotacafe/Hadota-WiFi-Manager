package com.hadota.wifimanager;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.SslErrorHandler;
import android.net.http.SslError;
import android.net.wifi.WifiManager;
import android.net.DhcpInfo;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URI;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(11,16,23));
        getWindow().setNavigationBarColor(Color.rgb(11,16,23));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(11,16,23));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                String u = request.getUrl().toString();
                if (u.startsWith("hadota://capture")) { captureRouterPage(); return true; }
                return false;
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (url != null && (url.startsWith("http://" + getGatewayAddress()) || url.startsWith("https://" + getGatewayAddress()))) {
                    view.evaluateJavascript("(function(){if(document.getElementById('hadotaCaptureBtn'))return;var b=document.createElement('button');b.id='hadotaCaptureBtn';b.textContent='استيراد الأجهزة إلى Hadota';b.style='position:fixed;z-index:2147483647;top:8px;left:8px;padding:13px 16px;background:#d9b36a;color:#17120a;border:2px solid #fff;border-radius:12px;font-weight:bold;font-size:16px;box-shadow:0 2px 12px #000';b.onclick=function(){location.href='hadota://capture'};document.body.appendChild(b);})();", null);
                }
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                String host = error.getUrl() == null ? "" : android.net.Uri.parse(error.getUrl()).getHost();
                if (host != null && host.equals(getGatewayAddress())) handler.proceed(); else handler.cancel();
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }


    private void openRouterPanel() {
        runOnUiThread(() -> {
            if (web != null) {
                web.removeJavascriptInterface("AndroidBridge");
                web.loadUrl("https://" + getGatewayAddress() + "/");
            }
        });
    }

    private void captureRouterPage() {
        if (web == null) return;
        web.evaluateJavascript("(function(){return document.body?document.body.innerText:''})()", value -> {
            String text = value == null ? "" : value;
            try { text = new org.json.JSONArray("[" + text + "]").optString(0, ""); } catch(Exception ignored) {}
            org.json.JSONArray devices = parseRouterClients(text);
            web.removeJavascriptInterface("AndroidBridge");
            web.loadUrl("file:///android_asset/index.html");
            web.postDelayed(() -> {
                if (web != null) {
                    web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
                    web.evaluateJavascript("showLiveDevices(" + devices.toString() + ")", null);
                }
            }, 700);
        });
    }

    private org.json.JSONArray parseRouterClients(String text) {
        org.json.JSONArray out = new org.json.JSONArray();
        java.util.regex.Matcher blocks = Pattern.compile("(?is)Client[- ](\\d+)(.*?)(?=Client[- ]\\d+|LAN Client Status|USB Storage Status|$)").matcher(text);
        while (blocks.find()) {
            String b = blocks.group(2);
            String ip = findValue(b, "IPv4 Address\\s*[:\\n]\\s*([0-9]{1,3}(?:\\.[0-9]{1,3}){3})");
            String mac = findValue(b, "MAC Address\\s*[:\\n]\\s*([0-9a-fA-F:]{17})");
            String name = findValue(b, "Name\\s*[:\\n]\\s*([^\\n]+)");
            if (ip.isEmpty() || mac.isEmpty()) continue;
            org.json.JSONObject d = new org.json.JSONObject();
            try { d.put("name", name.isEmpty() ? "جهاز متصل" : name.trim()); d.put("ip", ip); d.put("mac", mac.toLowerCase(java.util.Locale.ROOT)); d.put("source", "WLAN"); d.put("group", mac.equalsIgnoreCase("12:b1:0d:bd:b3:4a") ? "owner" : "staff"); out.put(d); } catch(Exception ignored) {}
        }
        // LAN client rows are shown separately by this ZTE firmware.
        java.util.regex.Matcher lan = Pattern.compile("(?is)LAN Client Status(.*?)(?=USB Storage Status|$)").matcher(text);
        if (lan.find()) {
            String b = lan.group(1);
            String ip = findValue(b, "IPv4 Address\\s*[:\\n]\\s*([0-9]{1,3}(?:\\.[0-9]{1,3}){3})");
            String mac = findValue(b, "MAC Address\\s*[:\\n]\\s*([0-9a-fA-F:]{17})");
            if (!ip.isEmpty() && !mac.isEmpty()) {
                org.json.JSONObject d = new org.json.JSONObject();
                try { d.put("name", "LAN device"); d.put("ip", ip); d.put("mac", mac.toLowerCase(java.util.Locale.ROOT)); d.put("source", "LAN"); d.put("group", "staff"); out.put(d); } catch(Exception ignored) {}
            }
        }
        return out;
    }
    private String findValue(String s, String regex) {
        java.util.regex.Matcher m = Pattern.compile("(?is)" + regex).matcher(s);
        return m.find() ? m.group(1).trim() : "";
    }

    private String getGatewayAddress() {
        try {
            WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wifi != null) {
                DhcpInfo dhcp = wifi.getDhcpInfo();
                int ip = dhcp.gateway;
                if (ip != 0) {
                    return (ip & 0xff) + "." + ((ip >> 8) & 0xff) + "." +
                           ((ip >> 16) & 0xff) + "." + ((ip >> 24) & 0xff);
                }
            }
        } catch (Exception ignored) {}
        return "192.168.1.1";
    }

    private class AndroidBridge {
        @JavascriptInterface public void openRouterPanel() { MainActivity.this.openRouterPanel(); }
        @JavascriptInterface public String getRouterGateway() { return getGatewayAddress(); }
        @JavascriptInterface public void testRouter() {
            executor.execute(() -> {
                HttpURLConnection connection = null;
                boolean ok = false;
                String message;
                long started = System.currentTimeMillis();
                try {
                    String gateway = getGatewayAddress();
                    URL url = new URL("http://" + gateway + "/");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(5000);
                    connection.setReadTimeout(5000);
                    connection.setInstanceFollowRedirects(false);
                    connection.setRequestProperty("User-Agent", "HadotaWiFiManager/1.3");
                    int code = connection.getResponseCode();
                    long elapsed = System.currentTimeMillis() - started;
                    String server = connection.getHeaderField("Server");
                    String location = connection.getHeaderField("Location");
                    ok = code >= 200 && code < 500;
                    StringBuilder details = new StringBuilder();
                    details.append("عنوان البوابة: ").append(gateway)
                           .append("\nاستجابة الراوتر: HTTP ").append(code)
                           .append("\nزمن الاستجابة: ").append(elapsed).append(" ms");
                    if (server != null && !server.isEmpty()) details.append("\nالخادم: ").append(server);
                    if (location != null && !location.isEmpty()) details.append("\nإعادة توجيه إلى: ").append(location);
                    details.append("\n\nهذا اختبار وصول وقراءة معلومات عامة فقط؛ لم تتم محاولة تسجيل الدخول أو تغيير إعدادات الراوتر.");
                    message = details.toString();
                } catch (Exception e) {
                    message = "تعذر الوصول إلى 192.168.1.1. تأكد من اتصال الهاتف بشبكة الكافيه، ثم تحقق من عنوان البوابة في إعدادات Wi‑Fi.";
                } finally {
                    if (connection != null) connection.disconnect();
                }
                final boolean result = ok;
                final String text = message;
                runOnUiThread(() -> {
                    if (web != null) web.evaluateJavascript("routerResult(" + result + "," + org.json.JSONObject.quote(text) + ")", null);
                });
            });
        }

        @JavascriptInterface public void inspectRouterLogin() {
            executor.execute(() -> {
                HttpURLConnection connection = null;
                String message;
                try {
                    String gateway = getGatewayAddress();
                    URL url = new URL("http://" + gateway + "/");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(7000);
                    connection.setReadTimeout(7000);
                    connection.setInstanceFollowRedirects(true);
                    connection.setRequestProperty("User-Agent", "HadotaWiFiManager/1.3");
                    int code = connection.getResponseCode();
                    String finalUrl = connection.getURL().toString();
                    InputStream stream = code >= 400 ? connection.getErrorStream() : connection.getInputStream();
                    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                    if (stream != null) {
                        byte[] chunk = new byte[4096]; int count; int total = 0;
                        while ((count = stream.read(chunk)) > 0 && total < 180000) {
                            int take = Math.min(count, 180000 - total); buffer.write(chunk, 0, take); total += take;
                        }
                        stream.close();
                    }
                    String html = buffer.toString("UTF-8");
                    Matcher titleMatch = Pattern.compile("(?is)<title[^>]*>(.*?)</title>").matcher(html);
                    String title = titleMatch.find() ? titleMatch.group(1).replaceAll("<[^>]+>", " ").trim() : "غير ظاهر";
                    Matcher formMatch = Pattern.compile("(?is)<form\\b([^>]*)>").matcher(html);
                    String form = formMatch.find() ? "نموذج HTML موجود" : "لم يظهر نموذج HTML مباشر (قد تكون الصفحة مبنية بجافاسكريبت)";
                    Matcher inputMatch = Pattern.compile("(?is)<input\\b([^>]*)>").matcher(html);
                    StringBuilder fields = new StringBuilder(); int fieldCount = 0;
                    while (inputMatch.find() && fieldCount < 18) {
                        String attrs = inputMatch.group(1);
                        Matcher nameMatch = Pattern.compile("(?is)\\bname\\s*=\\s*['\"]([^'\"]+)['\"]").matcher(attrs);
                        Matcher typeMatch = Pattern.compile("(?is)\\btype\\s*=\\s*['\"]([^'\"]+)['\"]").matcher(attrs);
                        if (nameMatch.find()) { if (fieldCount > 0) fields.append(", "); fields.append(nameMatch.group(1)); if (typeMatch.find()) fields.append(" [").append(typeMatch.group(1)).append("]"); fieldCount++; }
                    }
                    Matcher scriptMatch = Pattern.compile("(?is)<script\\b([^>]*)>").matcher(html);
                    StringBuilder scripts = new StringBuilder(); int scriptCount = 0;
                    while (scriptMatch.find() && scriptCount < 10) {
                        Matcher srcMatch = Pattern.compile("(?is)\\bsrc\\s*=\\s*['\"]([^'\"]+)['\"]").matcher(scriptMatch.group(1));
                        if (srcMatch.find()) { if (scriptCount > 0) scripts.append(", "); scripts.append(srcMatch.group(1)); scriptCount++; }
                    }
                    message = "فحص قراءة فقط — HTTP " + code + "\nعنوان البوابة المكتشف: " + gateway + "\nالعنوان النهائي: " + finalUrl + "\nعنوان الصفحة: " + title + "\n" + form + "\nحقول الصفحة: " + (fields.length() == 0 ? "لا توجد حقول ظاهرة" : fields) + "\nملفات JavaScript: " + (scripts.length() == 0 ? "لا توجد ملفات مرتبطة ظاهرة" : scripts) + "\nحجم HTML المقروء: " + html.length() + " حرفًا\n\nلم يتم تسجيل الدخول أو إرسال بيانات أو تغيير أي إعداد.";
                } catch (Exception e) {
                    message = "تعذر فحص صفحة الراوتر: " + e.getMessage();
                } finally {
                    if (connection != null) connection.disconnect();
                }
                final String result = message;
                runOnUiThread(() -> { if (web != null) web.evaluateJavascript("routerInspectResult(" + org.json.JSONObject.quote(result) + ")", null); });
            });
        }

        @JavascriptInterface public void inspectRouterScripts() {
            executor.execute(() -> {
                String message;
                HttpURLConnection page = null;
                try {
                    String gateway = getGatewayAddress();
                    URL baseUrl = new URL("http://" + gateway + "/");
                    page = (HttpURLConnection) baseUrl.openConnection();
                    page.setConnectTimeout(7000); page.setReadTimeout(7000);
                    page.setInstanceFollowRedirects(true);
                    page.setRequestProperty("User-Agent", "HadotaWiFiManager/1.4.2");
                    int status = page.getResponseCode();
                    URL pageUrl = page.getURL();
                    InputStream input = status >= 400 ? page.getErrorStream() : page.getInputStream();
                    String html = readLimited(input, 220000);
                    page.disconnect(); page = null;

                    StringBuilder paths = new StringBuilder();
                    StringBuilder sources = new StringBuilder();
                    int fetched = 0, inlineCount = 0, skipped = 0, matches = 0;
                    Pattern routePattern = Pattern.compile("(?i)(?:['\\\"])([^'\\\"]{1,220})(?:['\\\"])");
                    Pattern srcPattern = Pattern.compile("(?is)\\bsrc\\s*=\\s*['\\\"]([^'\\\"]+)['\\\"]");
                    Matcher scriptTags = Pattern.compile("(?is)<script\\b([^>]*)>(.*?)</script\\s*>").matcher(html);
                    while (scriptTags.find() && fetched + inlineCount < 25) {
                        String attrs = scriptTags.group(1);
                        String inlineBody = scriptTags.group(2);
                        Matcher srcMatch = srcPattern.matcher(attrs);
                        String body = inlineBody;
                        if (srcMatch.find()) {
                            String src = srcMatch.group(1).trim();
                            URL scriptUrl = new URL(pageUrl, src);
                            if (!scriptUrl.getHost().equalsIgnoreCase(pageUrl.getHost())) {
                                skipped++;
                                if (sources.length() < 1200) sources.append("\nتم تجاوز مصدر خارجي: ").append(src);
                                continue;
                            }
                            HttpURLConnection js = (HttpURLConnection) scriptUrl.openConnection();
                            js.setConnectTimeout(5000); js.setReadTimeout(5000);
                            js.setInstanceFollowRedirects(true);
                            js.setRequestProperty("User-Agent", "HadotaWiFiManager/1.4.2");
                            int jsCode = js.getResponseCode();
                            InputStream jsInput = jsCode >= 400 ? js.getErrorStream() : js.getInputStream();
                            body = readLimited(jsInput, 350000);
                            js.disconnect(); fetched++;
                            if (sources.length() < 1200) sources.append("\nتم فحص: ").append(scriptUrl.getPath()).append(" (HTTP ").append(jsCode).append(")");
                        } else {
                            if (body.trim().isEmpty()) continue;
                            inlineCount++;
                        }
                        Matcher strings = routePattern.matcher(body);
                        while (strings.find() && matches < 60) {
                            String candidate = strings.group(1).trim();
                            String lower = candidate.toLowerCase(Locale.ROOT);
                            boolean relevant = (candidate.startsWith("/") || lower.contains("/cgi-bin/") || lower.contains("get") || lower.contains("query")) &&
                                (lower.contains("dhcp") || lower.contains("device") || lower.contains("client") ||
                                 lower.contains("wlan") || lower.contains("wireless") || lower.contains("host") ||
                                 lower.contains("arp") || lower.contains("lan") || lower.contains("login") ||
                                 lower.contains("token") || lower.contains("network") || lower.contains("status") ||
                                 lower.contains("qos") || lower.contains("bandwidth") || lower.contains("traffic"));
                            if (relevant && paths.indexOf(candidate) < 0) {
                                if (matches > 0) paths.append("\n");
                                paths.append(candidate); matches++;
                            }
                        }
                    }
                    message = "تحليل قراءة فقط — HTTP " + status +
                        "\nملفات JavaScript المحلية التي تم تحميلها: " + fetched +
                        "\nكتل JavaScript داخل الصفحة: " + inlineCount +
                        "\nمصادر خارجية تم تجاوزها لأسباب الأمان: " + skipped +
                        "\nالمسارات المحتملة للأجهزة أو الشبكة أو QoS: " +
                        (matches == 0 ? "لم يظهر مسار واضح في الملفات المقروءة" : "\n" + paths) +
                        (sources.length() == 0 ? "" : "\n\nتفاصيل المصادر:" + sources) +
                        "\n\nفحص قراءة فقط؛ لم يتم تسجيل الدخول أو إرسال بيانات أو تغيير أي إعداد.";
                } catch (Exception e) {
                    message = "تعذر تحليل ملفات الراوتر: " + e.getClass().getSimpleName() + ": " + e.getMessage();
                } finally {
                    if (page != null) page.disconnect();
                }
                final String result = message;
                runOnUiThread(() -> { if (web != null) web.evaluateJavascript(
                    "routerScriptsResult(" + org.json.JSONObject.quote(result) + ")", null); });
            });
        }

        private String readLimited(InputStream stream, int maxBytes) throws Exception {
            if (stream == null) return "";
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096]; int count, total = 0;
            while ((count = stream.read(buffer)) > 0 && total < maxBytes) {
                int take = Math.min(count, maxBytes - total);
                out.write(buffer, 0, take); total += take;
            }
            stream.close();
            return out.toString("UTF-8");
        }

    }

        @Override protected void onDestroy() {
        if (web != null) { web.removeJavascriptInterface("AndroidBridge"); web.destroy(); web = null; }
        executor.shutdownNow();
        super.onDestroy();
    }
}
